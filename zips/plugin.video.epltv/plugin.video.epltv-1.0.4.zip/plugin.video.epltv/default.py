# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Premier League TV by Cazlo
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Author: Cazlo
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.epltv'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = ""
YOUTUBE_CHANNEL_ID_2 = "ArsenalTour"
YOUTUBE_CHANNEL_ID_3 = "avfcofficial"
YOUTUBE_CHANNEL_ID_4 = "officialbcfc"
YOUTUBE_CHANNEL_ID_5 = "onerovers1875"
YOUTUBE_CHANNEL_ID_6 = "OfficialBWFC"
YOUTUBE_CHANNEL_ID_7 = "officiacherries"
YOUTUBE_CHANNEL_ID_8 = "officialbhafc"
YOUTUBE_CHANNEL_ID_9 = "officialburnleyfc"
YOUTUBE_CHANNEL_ID_10 = "BluebirdsPlayer"
YOUTUBE_CHANNEL_ID_11 = "CAFCOfficial"
YOUTUBE_CHANNEL_ID_12 = "chelseafc"
YOUTUBE_CHANNEL_ID_13 = "OfficialCPFC"
YOUTUBE_CHANNEL_ID_14 = "DCTV1884"
YOUTUBE_CHANNEL_ID_15 = "OfficialEverton"
YOUTUBE_CHANNEL_ID_16 = "FulhamFC1987Ltd"
YOUTUBE_CHANNEL_ID_17 = "OfficialHTAFC"
YOUTUBE_CHANNEL_ID_18 = "HCAFCOfficial"
YOUTUBE_CHANNEL_ID_19 = "officialitfc"
YOUTUBE_CHANNEL_ID_20 = "UCVuUsbfP3TtTahZ2pkgSC_Q"
YOUTUBE_CHANNEL_ID_21 = "LCFCOfficial"
YOUTUBE_CHANNEL_ID_22 = "LiverpoolFC"
YOUTUBE_CHANNEL_ID_23 = "mcfcofficial"
YOUTUBE_CHANNEL_ID_24 = "FullTimeDevils"
YOUTUBE_CHANNEL_ID_25 = "UCdXWsJhkXzx5hFJGcxjy_5Q"
YOUTUBE_CHANNEL_ID_26 = "NUFCOfficial1892"
YOUTUBE_CHANNEL_ID_27 = "NCFCTube"
YOUTUBE_CHANNEL_ID_28 = "officialpfc"
YOUTUBE_CHANNEL_ID_29 = "OfficialQPR"
YOUTUBE_CHANNEL_ID_30 = "OfficialReadingFC"
YOUTUBE_CHANNEL_ID_31 = "SheffieldUTube"
YOUTUBE_CHANNEL_ID_32 = "theofficialsaints"
YOUTUBE_CHANNEL_ID_33 = "UCmFPjHUFr0hyE6eFGvCm7IA"
YOUTUBE_CHANNEL_ID_34 = "sunderlandafc"
YOUTUBE_CHANNEL_ID_35 = "SWANSPLAYER"
YOUTUBE_CHANNEL_ID_36 = "spursofficial"
YOUTUBE_CHANNEL_ID_37 = "WatfordFCofficial"
YOUTUBE_CHANNEL_ID_38 = "OfficialAlbion"
YOUTUBE_CHANNEL_ID_39 = "UCCNOsmurvpEit9paBOzWtUg"
YOUTUBE_CHANNEL_ID_40 = "LaticsOfficial"
YOUTUBE_CHANNEL_ID_41 = "OfficialWolvesVideo"
YOUTUBE_CHANNEL_ID_42 = ""
YOUTUBE_CHANNEL_ID_43 = "PL9DFh-nciQhR5NElxAarHhe4RP3bGCtX4"
YOUTUBE_CHANNEL_ID_44 = "TheFootballDaily"
YOUTUBE_CHANNEL_ID_45 = "UCI6FTSr584Y83UHL3u01auQ"
YOUTUBE_CHANNEL_ID_46 = "UCvVYl9jCALWgRdBv0FkDEWA"
YOUTUBE_CHANNEL_ID_47 = "UCPyMJYIAquNnntW18eZFJKQ"
YOUTUBE_CHANNEL_ID_48 = "UCWqrM-2uP5_H10m5tUP0x-w"
YOUTUBE_CHANNEL_ID_49 = "BeanymanSports"
YOUTUBE_CHANNEL_ID_50 = "UCNAf1k0yIjyGu3k9BwAg3lg"
YOUTUBE_CHANNEL_ID_51 = "UCjoj16PAB4l1o8B6I7dgD8Q"
YOUTUBE_CHANNEL_ID_52 = "UCVKz4bU1q9UNU6BHZK8h_ZA"
YOUTUBE_CHANNEL_ID_53 = "F2Freestylers"
YOUTUBE_CHANNEL_ID_54 = "FTBproMedia"
YOUTUBE_CHANNEL_ID_55 = "UCz01n8N8XfgKWLr0jkV3pXg"
YOUTUBE_CHANNEL_ID_56 = "UCGYYNGmyhZ_kwBF_lqqXdAQ"
YOUTUBE_CHANNEL_ID_57 = "UCTfo-i9DJYa0Zl4jfmK_OrQ"
YOUTUBE_CHANNEL_ID_58 = "UCAYpz2BUHuz5JAkP8_YBOAg"
YOUTUBE_CHANNEL_ID_59 = "UCQbscjnh3gdVsjjUKusiIKQ"
YOUTUBE_CHANNEL_ID_60 = "UCZ6P3ciwRWsaHiUhl1Q1Jfg"
YOUTUBE_CHANNEL_ID_61 = "arsenalfanstv"
YOUTUBE_CHANNEL_ID_62 = "ManUnitedProductions"
YOUTUBE_CHANNEL_ID_63 = "WeAreTheRedmen"
YOUTUBE_CHANNEL_ID_64 = "UCB76jtOddPPCX3XcXPV2d1Q"
YOUTUBE_CHANNEL_ID_65 = "stadiumastro"
YOUTUBE_CHANNEL_ID_66 = "Ballstreetchannel"
YOUTUBE_CHANNEL_ID_67 = "Copa90football"


# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="[COLOR gold]----- Official EPL YouTube Channels -----[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://raw.githubusercontent.com/cazloz/cazlo-repo/master/artwork/epltv-official.jpg",
        folder=False )

    plugintools.add_item( 
        #action="", 
        title="Arsenal",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://yt3.ggpht.com/-dZ2LhrpNpxs/AAAAAAAAAAI/AAAAAAAAAAA/L0Wl0cFKYhE/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Aston Villa",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://yt3.ggpht.com/-bkdSjte9SXI/AAAAAAAAAAI/AAAAAAAAAAA/NiYwkFL5JUc/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Birmingham",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="https://yt3.ggpht.com/-ANVKWwwOkrw/AAAAAAAAAAI/AAAAAAAAAAA/BcSxe7-Q2Xc/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Blackburn Rovers",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="https://yt3.ggpht.com/-KXy0zudqOfA/AAAAAAAAAAI/AAAAAAAAAAA/oMtd9dd6IxI/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Bolton Wanderers",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="https://yt3.ggpht.com/-gN0PEbpxQqc/AAAAAAAAAAI/AAAAAAAAAAA/NRQuTqQd0ko/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )                

    plugintools.add_item( 
        #action="", 
        title="Bournemouth",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="https://yt3.ggpht.com/--yGo12Wrsao/AAAAAAAAAAI/AAAAAAAAAAA/g0TFxZDPkEU/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )  

    plugintools.add_item( 
        #action="", 
        title="Brighton & Hove Albion",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="https://yt3.ggpht.com/-H0zbJvKdX4A/AAAAAAAAAAI/AAAAAAAAAAA/1B46uxvjUK8/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Burnley",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="https://yt3.ggpht.com/-nteZr1o0mYE/AAAAAAAAAAI/AAAAAAAAAAA/JBf_K2-kiGs/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Cardiff City",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="https://yt3.ggpht.com/-IA_o16orIHc/AAAAAAAAAAI/AAAAAAAAAAA/zZqHzMrxHZQ/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Charlton Athletic",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="https://yt3.ggpht.com/-VI6_imDRc88/AAAAAAAAAAI/AAAAAAAAAAA/Q3Q2yv3eHZk/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )    

    plugintools.add_item( 
        #action="", 
        title="Chelsea",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="https://yt3.ggpht.com/-_-grPaix4ZQ/AAAAAAAAAAI/AAAAAAAAAAA/kCxr3PPmMu8/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )  

    plugintools.add_item( 
        #action="", 
        title="Crystal Palace",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="https://yt3.ggpht.com/-WrI8hqpRM2A/AAAAAAAAAAI/AAAAAAAAAAA/9xcgCZF9e1Q/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )  

    plugintools.add_item( 
        #action="", 
        title="Derby County",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="https://yt3.ggpht.com/-e2CGqgpKrNk/AAAAAAAAAAI/AAAAAAAAAAA/0nIk02alAmc/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True ) 
		
    plugintools.add_item( 
        #action="", 
        title="Everton",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="https://yt3.ggpht.com/-JHwrktRrH8Y/AAAAAAAAAAI/AAAAAAAAAAA/fA4y9N-DQ7I/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Fulham",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail="https://yt3.ggpht.com/-xJxuStkE930/AAAAAAAAAAI/AAAAAAAAAAA/-KJ0pMHCZ1k/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Huddersfield Town",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_17+"/",
        thumbnail="https://yt3.ggpht.com/-xoAcYFO8SOk/AAAAAAAAAAI/AAAAAAAAAAA/a456lAB2WmA/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Hull City",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_18+"/",
        thumbnail="https://yt3.ggpht.com/-FDAxACUt9YM/AAAAAAAAAAI/AAAAAAAAAAA/k-dobdHquJQ/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Ipswich Town",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_19+"/",
        thumbnail="https://yt3.ggpht.com/-Uhq7UYWOUg8/AAAAAAAAAAI/AAAAAAAAAAA/oVx5M6XjLkk/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Leeds United",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_20+"/",
        thumbnail="https://yt3.ggpht.com/-UJ4LAJlRkVE/AAAAAAAAAAI/AAAAAAAAAAA/MAngO5Nvy-g/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="Leicester City",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_21+"/",
        thumbnail="https://yt3.ggpht.com/-sV7x6UqxV5k/AAAAAAAAAAI/AAAAAAAAAAA/UVUE_d5BD9A/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Liverpool",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_22+"/",
        thumbnail="https://yt3.ggpht.com/-TrtEHOgcMFE/AAAAAAAAAAI/AAAAAAAAAAA/K547x_dy1bY/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Manchester City",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_23+"/",
        thumbnail="https://yt3.ggpht.com/-WQH-4G14xyQ/AAAAAAAAAAI/AAAAAAAAAAA/8ND75PLcsH4/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Manchester United (Unofficial)",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_24+"/",
        thumbnail="http://2.bp.blogspot.com/-vkvNrCdLI5M/Tu7YAzMHzGI/AAAAAAAAAAc/JUr0FmSum1Q/s1600/1.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Middlesbrough",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_25+"/",
        thumbnail="https://yt3.ggpht.com/-bC7j9JsB7Vc/AAAAAAAAAAI/AAAAAAAAAAA/yp3LP3_HMkg/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Newcastle United",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_26+"/",
        thumbnail="https://yt3.ggpht.com/-GpY1g4M32fM/AAAAAAAAAAI/AAAAAAAAAAA/Ts2F88aWgEI/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Norwich City",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_27+"/",
        thumbnail="https://yt3.ggpht.com/--XlWV-Tk8gw/AAAAAAAAAAI/AAAAAAAAAAA/hBkiT8rMGt0/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Portsmouth",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_28+"/",
        thumbnail="https://yt3.ggpht.com/-ALlr0I0Xp94/AAAAAAAAAAI/AAAAAAAAAAA/MPGzCDVWeXg/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Queens Park Rangers",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_29+"/",
        thumbnail="https://yt3.ggpht.com/-ml7NgfzT5_g/AAAAAAAAAAI/AAAAAAAAAAA/lAPLFt8a-ws/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Reading FC",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_30+"/",
        thumbnail="https://yt3.ggpht.com/-30ca9L19e70/AAAAAAAAAAI/AAAAAAAAAAA/qQIeCHUbqTE/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Sheffield United",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_31+"/",
        thumbnail="https://yt3.ggpht.com/-8RbP3vFJdqE/AAAAAAAAAAI/AAAAAAAAAAA/v4c37g_0OXE/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )                

    plugintools.add_item( 
        #action="", 
        title="Southampton",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_32+"/",
        thumbnail="https://yt3.ggpht.com/-1fyh8BCWATw/AAAAAAAAAAI/AAAAAAAAAAA/PceSR8axjjk/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )  

    plugintools.add_item( 
        #action="", 
        title="Stoke City",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_33+"/",
        thumbnail="https://yt3.ggpht.com/-dmb21JHr1Ys/AAAAAAAAAAI/AAAAAAAAAAA/1xiSkfJizog/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Sunderland",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_34+"/",
        thumbnail="https://yt3.ggpht.com/-WsJ2xPB8MuU/AAAAAAAAAAI/AAAAAAAAAAA/hpjKmyt62f0/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Swansea City",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_35+"/",
        thumbnail="https://yt3.ggpht.com/-R8_vIBcoT0U/AAAAAAAAAAI/AAAAAAAAAAA/1PTSvKL_M0k/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Tottenham Hotspur",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_36+"/",
        thumbnail="https://yt3.ggpht.com/-t0SomHTxYHY/AAAAAAAAAAI/AAAAAAAAAAA/5vnpIjQhZgw/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )    

    plugintools.add_item( 
        #action="", 
        title="Watford",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_37+"/",
        thumbnail="https://yt3.ggpht.com/-83oXsQsPRiY/AAAAAAAAAAI/AAAAAAAAAAA/Aoq8G92bOZ8/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )  

    plugintools.add_item( 
        #action="", 
        title="West Bromwich Albion",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_38+"/",
        thumbnail="https://yt3.ggpht.com/-nFmGuNvcREA/AAAAAAAAAAI/AAAAAAAAAAA/PDDo6mQiLPA/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )  

    plugintools.add_item( 
        #action="", 
        title="West Ham United",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_39+"/",
        thumbnail="https://yt3.ggpht.com/-mpD6xlml_4I/AAAAAAAAAAI/AAAAAAAAAAA/wFl72OFOhIc/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True ) 

    plugintools.add_item( 
        #action="", 
        title="Wigan Athletic",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_40+"/",
        thumbnail="https://yt3.ggpht.com/-y6Q85w5-3hs/AAAAAAAAAAI/AAAAAAAAAAA/4JLQfayzXBE/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Wolverhampton Wanderers",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_41+"/",
        thumbnail="https://yt3.ggpht.com/-RG5JSj2qhcM/AAAAAAAAAAI/AAAAAAAAAAA/KT_-6QjwUKk/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="[COLOR gold]----- Football [COLOR red]X[/COLOR]travaganza -----[/COLOR]",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_42+"/",
        thumbnail="https://raw.githubusercontent.com/cazloz/cazlo-repo/master/artwork/epltv-xtra.jpg",
        folder=False )

    plugintools.add_item( 
        #action="", 
        title="Football Documentaries",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_43+"/",
        thumbnail="https://raw.githubusercontent.com/cazloz/cazlo-repo/master/artwork/epltv-docs.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Football Daily",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_44+"/",
        thumbnail="https://yt3.ggpht.com/-enmySwhRKW4/AAAAAAAAAAI/AAAAAAAAAAA/XyJeO8eB-4E/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="FOOTBALL SPOTLIGHT",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_45+"/",
        thumbnail="https://yt3.ggpht.com/-GPbIO1d6AxA/AAAAAAAAAAI/AAAAAAAAAAA/9GMytN_NfeU/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="EPL MOTD",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_46+"/",
        thumbnail="https://yt3.ggpht.com/-vxCQFp3eTwY/AAAAAAAAAAI/AAAAAAAAAAA/JSzbl73p9i8/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="OverClocked Football",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_47+"/",
        thumbnail="https://yt3.ggpht.com/-HDldApN17ss/AAAAAAAAAAI/AAAAAAAAAAA/7Pn_2hVXXFo/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="The Football Republic",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_48+"/",
        thumbnail="https://yt3.ggpht.com/-2Y_1_ERp2EE/AAAAAAAAAAI/AAAAAAAAAAA/WjpNzvZ-s_g/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Beanyman Sports",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_49+"/",
        thumbnail="https://yt3.ggpht.com/-uwS9Xe0abEo/AAAAAAAAAAI/AAAAAAAAAAA/xhfHg4CQm_8/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Sky Sports Football",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_50+"/",
        thumbnail="https://yt3.ggpht.com/-s4KkHI3fkVA/AAAAAAAAAAI/AAAAAAAAAAA/OSRu4_xgevM/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
    plugintools.add_item( 
        #action="", 
        title="The Football Terrace",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_51+"/",
        thumbnail="https://yt3.ggpht.com/-cU92_odPDmM/AAAAAAAAAAI/AAAAAAAAAAA/yViti-ce2S8/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
    plugintools.add_item( 
        #action="", 
        title="Absolutey Football",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_52+"/",
        thumbnail="https://yt3.ggpht.com/-HSgfRvU2l00/AAAAAAAAAAI/AAAAAAAAAAA/DvQz6E2qHsU/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="F2 Freestylers",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_53+"/",
        thumbnail="https://yt3.ggpht.com/-uiU0j4iHaU4/AAAAAAAAAAI/AAAAAAAAAAA/ToRc0gFqvuk/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="90min Football",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_54+"/",
        thumbnail="https://yt3.ggpht.com/-13cPJDZDd5g/AAAAAAAAAAI/AAAAAAAAAAA/nifvDIVKBdQ/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Football Today",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_55+"/",
        thumbnail="https://yt3.ggpht.com/-zDkCgp0OX8U/AAAAAAAAAAI/AAAAAAAAAAA/hyKh8fat3kw/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="uMAXit Football",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_56+"/",
        thumbnail="https://yt3.ggpht.com/--D0YCBk-EjY/AAAAAAAAAAI/AAAAAAAAAAA/Z4UyG6WITgY/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Footy MOTD ",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_57+"/",
        thumbnail="https://yt3.ggpht.com/-OFn8fv5oiWY/AAAAAAAAAAI/AAAAAAAAAAA/3OaVB9hUTJs/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Midnight Football",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_58+"/",
        thumbnail="https://yt3.ggpht.com/-YSbK3QfSx_w/AAAAAAAAAAI/AAAAAAAAAAA/gMmTR2AgPuc/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
    plugintools.add_item( 
        #action="", 
        title="Football World",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_59+"/",
        thumbnail="https://yt3.ggpht.com/-PWdI0w-3TCg/AAAAAAAAAAI/AAAAAAAAAAA/pOIt86WpPYg/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
    plugintools.add_item( 
        #action="", 
        title="YNWA Malaysia",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_60+"/",
        thumbnail="https://yt3.ggpht.com/-LjAnkSAlLYA/AAAAAAAAAAI/AAAAAAAAAAA/SfQmVoDK0rQ/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Arsenal Fan TV",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_61+"/",
        thumbnail="https://yt3.ggpht.com/-VioM2jMAG-8/AAAAAAAAAAI/AAAAAAAAAAA/qmhu4SQ8Qqk/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="MUTV HD Latest",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_62+"/",
        thumbnail="https://yt3.ggpht.com/-kGl3LEUEb9A/AAAAAAAAAAI/AAAAAAAAAAA/XNGpghFRhWM/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="The Redmen TV",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_63+"/",
        thumbnail="https://yt3.ggpht.com/-u0HNg7x_MEc/AAAAAAAAAAI/AAAAAAAAAAA/IkIfLRiRRlU/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="MUTV 247",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_64+"/",
        thumbnail="https://yt3.ggpht.com/-dZ3R2JIiGAw/AAAAAAAAAAI/AAAAAAAAAAA/D6Cx0H8MR5Q/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
    plugintools.add_item( 
        #action="", 
        title="Stadium Astro",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_65+"/",
        thumbnail="https://yt3.ggpht.com/-FN273hjIrGc/AAAAAAAAAAI/AAAAAAAAAAA/Vx7lunv6rZg/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
    plugintools.add_item( 
        #action="", 
        title="Ball Street",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_66+"/",
        thumbnail="https://yt3.ggpht.com/-fN4vkrcG8l4/AAAAAAAAAAI/AAAAAAAAAAA/uf20UzaWERY/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
    plugintools.add_item( 
        #action="", 
        title="Copa90",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_67+"/",
        thumbnail="https://yt3.ggpht.com/-AZbWU7KT3Yw/AAAAAAAAAAI/AAAAAAAAAAA/YfQCUPVWgMI/s288-c-k-no-mo-rj-c0xffffff/photo.jpg",
        folder=True )
run()
