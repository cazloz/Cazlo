# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Youtube Channel
# (c) 2017 - Deep House TV
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.deephousetv'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')


channellist=[
        ("Favorites", "playlist/PL9DFh-nciQhQoARixW4QJY5eMglByoNVR", 'https://raw.githubusercontent.com/cazloz/cazlo-repo/master/artwork/deephouse-favs.jpg'),
        ("Live House TV", "playlist/PL9DFh-nciQhTP03PVg3uQrYLO2UwMxhty", 'https://raw.githubusercontent.com/cazloz/cazlo-repo/master/artwork/deephouse-live.jpg'),			
        ("Sound of Soul", "channel/UCh2gZBX_qZ5qjkPY8x3bSSA", 'https://yt3.ggpht.com/-ZdNggDFIZDY/AAAAAAAAAAI/AAAAAAAAAAA/Xcnvx6WmmPM/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),	
        ("Soundeo", "channel/UCINHOGLmaYvqEfC5dvu7jCw", 'https://yt3.ggpht.com/-ual1MV6-eZo/AAAAAAAAAAI/AAAAAAAAAAA/fdzyEAd-rFE/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("Players", "channel/UC7qhZK_eaV_vLfXTXJIw_fQ", 'https://yt3.ggpht.com/-hAF0x_23PME/AAAAAAAAAAI/AAAAAAAAAAA/Z69Tqsmy_x0/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),			
        ("Deep Zone", "channel/UCfsScd9ztkzyrOTl5uJY-Cw", 'https://yt3.ggpht.com/-xHM9e_DGRlM/AAAAAAAAAAI/AAAAAAAAAAA/o4ztmD0x-u8/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("DJ Smile VIP", "channel/UCvdhZwrI0qZ2LLsMbMk4Kkg", 'https://yt3.ggpht.com/-lY1WfSpMNQA/AAAAAAAAAAI/AAAAAAAAAAA/DYEKvr-pces/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),	
        ("NDeep", "channel/UCrOh_gD5ITrrx_WH26WzSnA", 'https://yt3.ggpht.com/-TLgj0F0_qA0/AAAAAAAAAAI/AAAAAAAAAAA/RXQO1c6H5PQ/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("DJ Dark", "channel/UC1TpCkfbzIta8MwtJbxzzUA", 'https://yt3.ggpht.com/-FbppoYGBcOw/AAAAAAAAAAI/AAAAAAAAAAA/8aKSYKezhVQ/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),			
        ("Dj Nikos Danelakis (sets)", "channel/UCSScY3QALRU6HKzUt25T3fw", 'https://yt3.ggpht.com/-PPqQiXItCR8/AAAAAAAAAAI/AAAAAAAAAAA/Vo2NkL26um4/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("DJ Go (sets)", "channel/UCbG82JHDrN9t_yJHW1H2-Qw", 'https://yt3.ggpht.com/-BGQ8U3djptg/AAAAAAAAAAI/AAAAAAAAAAA/pXHT2vyiVFQ/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),	
        ("DJ Drop G (VJ sets)", "channel/UCPg3xfvygstC-AkG2Fg3ZXw", 'https://yt3.ggpht.com/-0cirbz4I_PU/AAAAAAAAAAI/AAAAAAAAAAA/7nigAQzB9Tc/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("Dr Deep (sets)", "channel/UC2UzOf-DydnkeiG7tL0R6Cw", 'https://yt3.ggpht.com/-82159gKc64U/AAAAAAAAAAI/AAAAAAAAAAA/pLeHVilsFBY/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),			
        ("Shine Music (sets)", "channel/UCz24srq31kr8CyNT-oN1Dqw", 'https://yt3.ggpht.com/-JXR0oKO4XqQ/AAAAAAAAAAI/AAAAAAAAAAA/nBd6TbmBbc8/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("XDeep Music (sets)", "channel/UCSSEXzYHBijpCPJdiZbS7mw", 'https://yt3.ggpht.com/-kS8xy0vSVDU/AAAAAAAAAAI/AAAAAAAAAAA/bggfl99bU7o/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),	
        ("Deep Territory (sets)", "channel/UCsGL3CaZZjKHmhAtO2Fx95w", 'https://yt3.ggpht.com/-aN5xMM0wVFA/AAAAAAAAAAI/AAAAAAAAAAA/Umd7xR04uBE/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("Magic Club (sets)", "channel/UCAJ1rjf90IFwNGlZUYuoP1Q", 'https://yt3.ggpht.com/-_xhAnsMSmI8/AAAAAAAAAAI/AAAAAAAAAAA/ywks2OWZ0EM/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),			
        ("MA Deep House (sets)", "channel/UCBtgo-02iSOm6HN5dHNYDFg", 'https://yt3.ggpht.com/-bgjkEs1eFRE/AAAAAAAAAAI/AAAAAAAAAAA/M5pWVehky5k/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("House Factory (sets)", "channel/UCFXAk5qz-X8QOS7WsrNN_Gg", 'https://yt3.ggpht.com/-1zSbgvar3As/AAAAAAAAAAI/AAAAAAAAAAA/-IqW-c7IfOI/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),	
        ("Feel the sound (sets)", "channel/UCg5XZgxVytarljBn4ueKqkg", 'https://yt3.ggpht.com/-WNYR4e_2O9Y/AAAAAAAAAAI/AAAAAAAAAAA/5lnXVY-n_Bk/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("Ahmed Kilic", "user/djahmet008", 'https://yt3.ggpht.com/-c_Yi_sSVLDw/AAAAAAAAAAI/AAAAAAAAAAA/4jj4Z4_7Dbo/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),			
        ("Mr DeepSence", "user/MrDeepSense", 'https://yt3.ggpht.com/-U15Ut65AO3I/AAAAAAAAAAI/AAAAAAAAAAA/wG_JGLcud7U/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("120bpm", "channel/UCO0RBMR9ILNLhy_mbWbF4dg", 'https://yt3.ggpht.com/-0CGcUtSaAvg/AAAAAAAAAAI/AAAAAAAAAAA/Xd6mGa3iKy8/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),	
        ("Base Deep", "channel/UC6LRklglaoc2ywIwmcv21qQ", 'https://yt3.ggpht.com/-RzQd-nnVVHI/AAAAAAAAAAI/AAAAAAAAAAA/Iz9UCjJlcD4/s288-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("DJ Regard (sets)", "channel/UCw39ZmFGboKvrHv4n6LviCA", 'https://yt3.ggpht.com/-Z6Mnb8qdA7A/AAAAAAAAAAI/AAAAAAAAAAA/CeU6rdpFLHI/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),			
        ("RikoDisco", "channel/UCwIjCoyJ0DwJRvX4256Uigg", 'https://yt3.ggpht.com/-5_fPzJWF2Fw/AAAAAAAAAAI/AAAAAAAAAAA/pJWQAkVILHY/s300-c-k-no-mo-rj-c0xffffff/photo.jpg'),			
]



# Entry point
def run():
    plugintools.log("youtubeAddon.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("youtubeAddon.main_list "+repr(params))

for name, id, icon in channellist:
	plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,folder=True )



run()