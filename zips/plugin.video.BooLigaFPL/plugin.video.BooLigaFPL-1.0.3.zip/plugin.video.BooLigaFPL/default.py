# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Youtube Channel
# (c) 2017 - BooLiga FPL TV
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.BooLigaFPL'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')


channellist=[
        ("BooLiga HD", "playlist/PL9DFh-nciQhQfjTdwlLa4Jw6SwbkqSaL9", 'https://raw.githubusercontent.com/cazloz/cazlo-repo/master/artwork/booligahd.jpg'),
        ("FPL tips", "channel/UCVPb_jLxwaoYd-Dm7aSWQKQ", 'https://yt3.ggpht.com/-jqx2Jvxid1E/AAAAAAAAAAI/AAAAAAAAAAA/hr1QARaMdTk/s288-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("FPL TV", "user/bretto17", 'https://yt3.ggpht.com/-NW2OWqi7z38/AAAAAAAAAAI/AAAAAAAAAAA/vIMW-5j_WGw/s288-c-k-no-mo-rj-c0xffffff/photo.jpg'),
		("FPL Updates & Tips", "channel/UCJcS0Lq04oMnhECIzZYNtxg", 'https://yt3.ggpht.com/-MRCa8KkGZzM/AAAAAAAAAAI/AAAAAAAAAAA/l8PBK9pVlkc/s200-c-k-no-mo-rj-c0xffffff/photo.jpg'),
        ("FPL Updates", "channel/UCd-ZeNTEUL6xxJezsILg8Lw", 'https://yt3.ggpht.com/-FXoMZa7AkGY/AAAAAAAAAAI/AAAAAAAAAAA/OGTovdny1vg/s288-c-k-no-mo-rj-c0xffffff/photo.jpg'),
		("Upper 90 Studios", "user/upper90studios", 'https://yt3.ggpht.com/-o-rjfF3iRBs/AAAAAAAAAAI/AAAAAAAAAAA/N7gRjok72D0/s288-c-k-no-mo-rj-c0xffffff/photo.jpg'),
		("Football World", "user/djshahrukhsrk", 'https://yt3.ggpht.com/-iS3h_WnLsyE/AAAAAAAAAAI/AAAAAAAAAAA/dogz20TJo2I/s288-c-k-no-mo-rj-c0xffffff/photo.jpg'),
		("FPL Today", "channel/UCM71eeg9X6ltVD02-p3tD_g", 'https://yt3.ggpht.com/-SUxSFmQkpEU/AAAAAAAAAAI/AAAAAAAAAAA/fFtfA96h-Co/s288-c-k-no-mo-rj-c0xffffff/photo.jpg'),
		("Let's Talk FPL", "channel/UCxeOc7eFxq37yW_Nc-69deA", 'https://yt3.ggpht.com/-O_7_FtInkxE/AAAAAAAAAAI/AAAAAAAAAAA/oJEp4t4t0xA/s288-c-k-no-mo-rj-c0xffffff/photo.jpg'),
		("Fantasy Football Manager", "channel/UCqSA2ey4AOUSmlN1dEsofig", 'https://yt3.ggpht.com/-JfrtaaexBHg/AAAAAAAAAAI/AAAAAAAAAAA/6YBCxcSrayM/s288-c-k-no-mo-rj-c0xffffff/photo.jpg'),	    				
		("Fantasy Football Fix", "channel/UC0Oaf88gRGnNkncI8D_GO-Q", 'https://yt3.ggpht.com/-wY6M_909nPo/AAAAAAAAAAI/AAAAAAAAAAA/dZy-9CAkcEk/s288-c-k-no-mo-rj-c0xffffff/photo.jpg'),	    				
]



# Entry point
def run():
    plugintools.log("youtubeAddon.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("youtubeAddon.main_list "+repr(params))

for name, id, icon in channellist:
	plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,folder=True )



run()